日文台本提取器桌面图标资源

将 res 文件夹内的内容合并到 japanese-script-extractor/app/src/main/res/。
然后在 AndroidManifest.xml 的 <application> 标签上添加：
android:icon="@mipmap/ic_launcher"
android:roundIcon="@mipmap/ic_launcher"

自适应图标适用于 Android 8.0+；mipmap-* 提供旧版兼容图标。
